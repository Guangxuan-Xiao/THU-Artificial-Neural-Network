`run.sh`为进行0~100% Dropout Rate，带有BN层CNN实验的脚本。

`run_no_batchnorm.sh`为60% Dropout Rate，不带BN层CNN实验的脚本。

`logs/`文件夹下为实验记录，可以看到训练过程。

`plots/`文件夹下为所有实验的训练曲线。